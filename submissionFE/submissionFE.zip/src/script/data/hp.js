let data = [
  {
    brand: "Apple",
    kode: "apple-phones-48",
  },
  {
    brand: "Asus",
    kode: "asus-phones-46",
  },
  {
    brand: "Nokia",
    kode: "nokia-phones-1",
  },
  {
    brand: "Oppo",
    kode: "oppo-phones-82",
  },
  {
    brand: "Xiaomi",
    kode: "xiaomi-phones-80",
  },
  {
    brand: "Samsung",
    kode: "samsung-phones-9",
  },
];

export default data;
